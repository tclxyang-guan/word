// Package color provides color handling structures and functions for use across
// all of the document types.
package color
